// express
const express = require("express");
const app = express();

// body-parser
app.use(express.urlencoded({extended:true}))


app.listen(8080,(req,res)=>{
    console.log('8080 포트 오픈');
})

app.get('/index',(req,res)=>{
    res.render('index.ejs');
})

app.get('/write',(req,res)=>{
    res.render('write.ejs');
})